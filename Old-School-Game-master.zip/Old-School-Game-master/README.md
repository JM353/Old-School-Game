# Old-School-Game
The aim is to create a game using the language C++. 
